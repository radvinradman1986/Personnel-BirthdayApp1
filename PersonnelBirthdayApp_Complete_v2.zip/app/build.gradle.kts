plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.example.personnelbirthday"; compileSdk=35
 defaultConfig { applicationId="com.example.personnelbirthday"; minSdk=26; targetSdk=35; versionCode=2; versionName="2.0" }
 buildTypes { release { isMinifyEnabled=true; isShrinkResources=true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro") } }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("androidx.activity:activity-ktx:1.10.0")
 implementation("androidx.biometric:biometric:1.2.0-alpha05")
 implementation("androidx.security:security-crypto:1.1.0-alpha06")
 implementation("androidx.work:work-runtime-ktx:2.10.0")
}