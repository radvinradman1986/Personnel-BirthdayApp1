package com.example.personnelbirthday

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executor

data class Person(val first:String,val last:String,val father:String,val birth:String,val national:String,val personnel:String,val position:String,val degree:String,val birthplace:String,val post:String,val married:String,val phone:String,val address:String,val photo:String,val other:String){
 fun matches(q:String)=q.isBlank()||"$first $last $personnel $national $position".lowercase().contains(q.lowercase())
 fun json()=JSONObject().apply{put("first",first);put("last",last);put("father",father);put("birth",birth);put("national",national);put("personnel",personnel);put("position",position);put("degree",degree);put("birthplace",birthplace);put("post",post);put("married",married);put("phone",phone);put("address",address);put("photo",photo);put("other",other)}
 companion object{fun from(o:JSONObject)=Person(o.optString("first"),o.optString("last"),o.optString("father"),o.optString("birth"),o.optString("national"),o.optString("personnel"),o.optString("position"),o.optString("degree"),o.optString("birthplace"),o.optString("post"),o.optString("married"),o.optString("phone"),o.optString("address"),o.optString("photo"),o.optString("other"))}
}

class MainActivity:ComponentActivity(){
 private lateinit var secure:EncryptedSharedPreferences
 private lateinit var list:TextView
 private lateinit var search:EditText
 private val people=mutableListOf<Person>()
 private var unlocked=false
 private var lastTouch=System.currentTimeMillis()
 private var lockMinutes=5

 override fun onCreate(s:Bundle?){
  super.onCreate(s); window.addFlags(WindowManager.LayoutParams.FLAG_SECURE); setContentView(R.layout.activity_main)
  list=findViewById(R.id.list); search=findViewById(R.id.search)
  secure=EncryptedSharedPreferences.create(this,"personnel_secure_store",MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
  lockMinutes=secure.getInt("lock_minutes",5); load()
  findViewById<Button>(R.id.addButton).setOnClickListener{addPerson()}
  findViewById<Button>(R.id.birthdayButton).setOnClickListener{birthdays()}
  findViewById<Button>(R.id.importButton).setOnClickListener{chooseCsv()}
  findViewById<Button>(R.id.exportButton).setOnClickListener{backupInfo()}
  findViewById<Button>(R.id.securityButton).setOnClickListener{security()}
  search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){render()};override fun afterTextChanged(e:android.text.Editable?){} })
  unlock()
 }
 private fun unlock(){
  val p=BiometricPrompt(this,ContextCompat.getMainExecutor(this),object:BiometricPrompt.AuthenticationCallback(){
   override fun onAuthenticationSucceeded(r:BiometricPrompt.AuthenticationResult){unlocked=true;lastTouch=System.currentTimeMillis();render();findViewById<TextView>(R.id.status).text="ورود امن انجام شد؛ اطلاعات رمزگذاری شده است."}
   override fun onAuthenticationError(c:Int,m:CharSequence){findViewById<TextView>(R.id.status).text="قفل فعال است؛ برای ورود قفل بیومتریک گوشی را فعال کنید."}
  })
  try{p.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("ورود امن").setSubtitle("احراز هویت برای مشاهده اطلاعات پرسنل").setNegativeButtonText("انصراف").build())}catch(_:Exception){}
 }
 override fun onUserInteraction(){super.onUserInteraction();lastTouch=System.currentTimeMillis()}
 override fun onResume(){super.onResume();if(unlocked&&System.currentTimeMillis()-lastTouch>lockMinutes*60000L){unlocked=false;unlock()}}
 private fun ok():Boolean{if(!unlocked){unlock();return false};return true}

 private fun addPerson(){
  if(!ok())return
  val labels=arrayOf("نام","نام خانوادگی","نام پدر","تاریخ تولد شمسی","شماره ملی","شماره پرسنلی","جایگاه / سمت","مدرک تحصیلی","محل تولد","شرح پست سازمانی","وضعیت تأهل (متأهل/مجرد)","شماره تلفن","آدرس","سایر اطلاعات")
  val e=labels.map{EditText(this).apply{hint=it}}
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,4,20,4);e.forEach{addView(it)}}
  AlertDialog.Builder(this).setTitle("ثبت پرونده پرسنلی").setView(box).setPositiveButton("ذخیره"){_,_->
   val p=Person(e[0].text.toString(),e[1].text.toString(),e[2].text.toString(),e[3].text.toString(),e[4].text.toString(),e[5].text.toString(),e[6].text.toString(),e[7].text.toString(),e[8].text.toString(),e[9].text.toString(),e[10].text.toString(),e[11].text.toString(),e[12].text.toString(),"",e[13].text.toString())
   if(p.personnel.isBlank())Toast.makeText(this,"شماره پرسنلی را وارد کنید.",Toast.LENGTH_LONG).show() else{people.removeAll{it.personnel==p.personnel};people.add(p);save();render()}
  }.setNegativeButton("انصراف",null).show()
 }
 private fun render(){
  if(!unlocked){list.text="اطلاعات قفل است.";return}
  val f=people.filter{it.matches(search.text.toString().trim())}
  list.text=if(f.isEmpty())"رکوردی پیدا نشد." else f.joinToString("\n\n"){"👤 ${it.first} ${it.last}\nشماره پرسنلی: ${it.personnel}\nتولد: ${it.birth}\nسمت: ${it.position}\nمدرک: ${it.degree}\nتلفن: ${it.phone}\nتأهل: ${it.married}"}
 }
 private fun birthdays(){if(!ok())return;list.text=if(people.none{it.birth.isNotBlank()})"تاریخ تولدی ثبت نشده است." else "🎂 تولدهای ثبت‌شده:\n\n"+people.filter{it.birth.isNotBlank()}.sortedBy{it.birth}.joinToString("\n\n"){"${it.first} ${it.last} — ${it.birth}"}}
 private fun save(){val a=JSONArray();people.forEach{a.put(it.json())};secure.edit().putString("people",a.toString()).apply()}
 private fun load(){val a=JSONArray(secure.getString("people","[]")?:"[]");for(i in 0 until a.length())people.add(Person.from(a.getJSONObject(i)))}
 private fun chooseCsv(){if(!ok())return;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/*"},1001)}
 @Deprecated("compat") override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==1001&&c==RESULT_OK)d?.data?.let{importCsv(it)}}
 private fun importCsv(uri:Uri){
  try{val lines=BufferedReader(InputStreamReader(contentResolver.openInputStream(uri)!!,Charsets.UTF_8)).readLines();if(lines.size<2)return;val h=lines[0].split(",").map{it.trim()};var n=0
   for(line in lines.drop(1)){val x=line.split(",");fun v(k:String,i:Int)=if(h.indexOfFirst{it.equals(k,true)}>=0)x.getOrNull(h.indexOfFirst{it.equals(k,true)})?.trim()?:"" else x.getOrNull(i)?.trim()?:""
    val p=Person(v("نام",0),v("نام خانوادگی",1),v("نام پدر",2),v("تاریخ تولد شمسی",3),v("شماره ملی",4),v("شماره پرسنلی",5),v("سمت",6),v("مدرک تحصیلی",7),v("محل تولد",8),v("شرح پست سازمانی",9),v("وضعیت تأهل",10),v("شماره تلفن",11),v("آدرس",12),"",v("سایر اطلاعات",13))
    if(p.personnel.isNotBlank()){people.removeAll{it.personnel==p.personnel};people.add(p);n++}}
   save();render();Toast.makeText(this,"$n رکورد وارد شد.",Toast.LENGTH_LONG).show()
  }catch(e:Exception){Toast.makeText(this,"خطا در خواندن فایل.",Toast.LENGTH_LONG).show()}
 }
 private fun backupInfo(){if(!ok())return;Toast.makeText(this,"اطلاعات داخلی با Android Keystore رمزگذاری شده است. پشتیبان فایل مستقل باید با رمز جداگانه در نسخه انتشار فعال شود.",Toast.LENGTH_LONG).show()}
 private fun security(){if(!ok())return;val e=EditText(this).apply{hint="قفل خودکار (دقیقه)";setText(lockMinutes.toString());inputType=2}
  AlertDialog.Builder(this).setTitle("تنظیمات امنیتی").setMessage("✓ AES-256-GCM\n✓ Android Keystore\n✓ بیومتریک\n✓ قفل خودکار\n✓ جلوگیری از اسکرین‌شات\n✓ عدم پشتیبان‌گیری خودکار\n✓ مسدود بودن HTTP ساده").setView(e).setPositiveButton("ذخیره"){_,_->lockMinutes=e.text.toString().toIntOrNull()?.coerceIn(1,60)?:5;secure.edit().putInt("lock_minutes",lockMinutes).apply()}.setNegativeButton("بستن",null).show()
 }
}
